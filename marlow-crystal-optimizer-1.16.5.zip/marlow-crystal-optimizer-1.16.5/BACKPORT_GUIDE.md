# Marlow's Crystal Optimizer - 1.16.5 Backport Guide

## Overview
This is a comprehensive backport of **Marlow's Crystal Optimizer** from Minecraft 1.19.X to **1.16.5** using **Fabric** and **Java 8**.

The mod optimizes End Crystal entity cleanup, fixing the lag that occurs after breaking crystals while waiting for server-side entity removal.

---

## Source Code Structure

```
src/main/java/com/deathmotion/marlowcrystal/
├── MarlowCrystal.java                 # Main mod entry point
├── handler/
│   └── InteractHandler.java            # Crystal interaction & cleanup logic
├── listener/
│   ├── ConnectEventListener.java       # Server connection handling
│   ├── DisconnectEventListener.java    # Server disconnection cleanup
│   ├── ChallengePacketListener.java    # Challenge packet responses
│   └── OptOutPacketListener.java       # Opt-out status management
├── packet/
│   ├── ModPackets.java                 # Packet channel registration
│   └── impl/
│       ├── ChallengePacket.java
│       ├── ChallengeResponsePacket.java
│       ├── OptOutPacket.java
│       ├── OptOutAckPacket.java
│       └── VersionPacket.java
├── mixin/
│   └── ClientConnectionMixin.java      # Network packet interception
├── cache/
│   └── OptOutCache.java                # Player opt-out tracking
└── util/
    ├── Logger.java                      # Logging wrapper
    ├── ConnectionUtil.java              # Server connection utilities
    └── datastructure/
        └── EvictingList.java            # LRU evicting list cache
```

---

## Key Changes from 1.19.X to 1.16.5

### 1. **Java Version**
- **1.19.X**: Java 17 (JAVA_17 compatibility level)
- **1.16.5**: Java 8 (JAVA_8 compatibility level)
- All modern language features (records, sealed classes) removed
- Traditional class-based implementations used

### 2. **Fabric API Version**
- **1.19.X**: fabric-api 0.42.0+1.19
- **1.16.5**: fabric-api 0.42.0+1.16
- Event APIs compatible but some modernized event names differ

### 3. **Networking Changes**
- **1.19.X**: Uses newer `CustomPayloadC2SPacket`
- **1.16.5**: Still compatible but some network handler signatures differ
- Packet encoding/decoding methods consistent across versions

### 4. **Entity Classes**
- `EndCrystalEntity` available in both versions
- Method names for entity state checking may vary slightly
- Property access patterns remain similar

### 5. **ClientConnection Mixin**
- **1.19.X**: `ClientConnection.send()` and `handlePacket()` methods
- **1.16.5**: Same methods, same signatures - no changes needed
- Bytecode injection points identical

---

## Dependency Versions for 1.16.5

```gradle
// Core
minecraft_version = 1.16.5
yarn_mappings = 1.16.5+build.10
loader_version = 0.11.3

// APIs
fabric-api = 0.42.0+1.16
cloth-config = 4.16.91
modmenu = 1.16.23

// Build tools
fabric-loom = 0.11-SNAPSHOT
gradle = 7.4.2
```

---

## Building the 1.16.5 Mod

### Prerequisites
```bash
# Using SDKMAN (recommended for Codespaces)
sdk install java 8.0.372-zulu
sdk use java 8.0.372-zulu

# Or set JAVA_HOME manually
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
```

### Build Steps

```bash
# 1. Clone or prepare the project
git clone <your-repo-url>
cd marlow-crystal-optimizer-1.16.5

# 2. Build with Gradle
./gradlew build

# 3. Output JAR location
# build/libs/marlow-crystal-optimizer-1.1.0-1.16.5.jar
```

### Using GitHub Codespaces (Mobile-friendly)

```bash
# Install Java 8
sdk install java 8.0.372-zulu

# Navigate to project
cd /workspace/marlow-crystal-optimizer-1.16.5

# Build
./gradlew build

# Watch for build artifacts in build/libs/
```

---

## Code Compatibility Notes

### No Changes Required For:
- ✅ Packet encoding/decoding (PacketByteBuf API identical)
- ✅ Event listeners (ClientTickEvents, ClientPlayConnectionEvents)
- ✅ Entity iteration (World.getEntities() works the same)
- ✅ UUID handling and networking
- ✅ Logger/SLF4J integration
- ✅ Mixin application (`@Inject`, `@Redirect` compatible)

### Minor Adaptation (Already Done):
- ✅ Removed Java 17+ language features
- ✅ Compatibility level changed to JAVA_8 in mixins
- ✅ Some imports updated for 1.16.5 package paths
- ✅ Fabric Loader version in gradle.properties adjusted

---

## Network Packets

The mod uses custom packets for server-client communication:

### Packet Channels
- `marlowcrystal:challenge` - Server → Client (verification challenge)
- `marlowcrystal:challenge_response` - Client → Server (response)
- `marlowcrystal:opt_out` - Server → Client (opt-out status)
- `marlowcrystal:opt_out_ack` - Client → Server (acknowledgement)
- `marlowcrystal:version` - Bidirectional (version sync)

### Packet Structure
All packets implement encode/decode for PacketByteBuf:
```java
public static PacketType decode(PacketByteBuf buf) { ... }
public void encode(PacketByteBuf buf) { ... }
```

---

## Performance Optimizations

1. **Throttled Cleanup** (InteractHandler.java)
   - Cleanup operations run every 100ms, not every tick
   - Reduces CPU overhead from entity scanning

2. **Evicting Cache** (EvictingList.java)
   - LRU-style cache with max size of 100
   - Automatically removes oldest entries
   - Used for opt-out player tracking

3. **Selective Packet Logging**
   - Only logs crystal and entity-related packets
   - Reduces spam in debug logs
   - Improves performance in busy servers

---

## Testing Checklist

- [ ] Mod loads without errors in 1.16.5
- [ ] Connects to servers (event listeners trigger)
- [ ] Responds to server challenge packets
- [ ] Handles opt-out packet from server
- [ ] Cleans cache on disconnect
- [ ] No exceptions in logs during gameplay
- [ ] Crystal breaking/placing detection works
- [ ] Mixins apply without conflicts

---

## Troubleshooting

### Build Issues
```
Error: Could not determine java version from '21.0.10'

Solution: Set JAVA_HOME to Java 8
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
```

### Mixin Errors
```
Error: Unknown compatibility level: JAVA_8

Solution: fabric-loom 0.11+ should handle JAVA_8.
Ensure gradle.properties has correct fabric_loom version.
```

### Network Packet Issues
```
Error: Channel not available

Solution: Register packets in ModPackets.registerPackets()
called from MarlowCrystal.onInitializeClient()
```

---

## Publishing to GitHub

1. **Create Repository**
```bash
git init
git add .
git commit -m "Initial 1.16.5 backport"
git remote add origin https://github.com/yourusername/marlow-crystal-optimizer-1.16.5
git push -u origin main
```

2. **Tag Release**
```bash
git tag -a v1.1.0-1.16.5 -m "1.16.5 Backport Release"
git push origin v1.1.0-1.16.5
```

3. **Upload JAR Artifacts**
```bash
# Upload build/libs/marlow-crystal-optimizer-1.1.0-1.16.5.jar
# to GitHub Releases
```

---

## License
This backport maintains the **MIT License** from the original mod.

---

## Credits
- **Original Mod**: Bram & Marlow
- **1.16.5 Backport**: Your Name Here
- **Fabric Team**: For stable 1.16.5 modding tools

---

## References
- [Fabric Documentation](https://fabricmc.net/wiki/)
- [Fabric API 0.42.0 Javadocs](https://maven.fabricmc.net/docs/fabric-api/0.42.0%2B1.16/)
- [Mixin Documentation](https://docs.spongepowered.org/mixin/0.8.5/)

---

**Last Updated**: June 15, 2026
**Target Version**: Minecraft 1.16.5
**Mod Version**: 1.1.0
