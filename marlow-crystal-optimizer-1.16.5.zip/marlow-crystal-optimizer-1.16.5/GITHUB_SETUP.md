# 🚀 Quick GitHub Setup

This is ready to go! Just follow these steps:

## 1️⃣ Create GitHub Repository

- Go to **github.com**
- Click **New Repository**
- Name: `marlow-crystal-optimizer-1.16.5`
- Description: `Marlow's Crystal Optimizer - Minecraft 1.16.5 Backport`
- Make it **Public**
- Click **Create repository**

## 2️⃣ Upload This Code

```bash
# In this folder, run:
git init
git add .
git commit -m "Initial commit - 1.16.5 backport complete"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/marlow-crystal-optimizer-1.16.5
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username!

## 3️⃣ Build & Create Release

```bash
# Build the mod
./gradlew build

# Create a git tag
git tag v1.1.0-1.16.5
git push origin v1.1.0-1.16.5
```

Then:
- Go to GitHub → Releases
- Click "Create a release" for tag `v1.1.0-1.16.5`
- Upload `build/libs/marlow-crystal-optimizer-1.1.0-1.16.5.jar`
- Click "Publish release"

## 4️⃣ Share

Share the link: `https://github.com/YOUR_USERNAME/marlow-crystal-optimizer-1.16.5`

Done! 🎉
