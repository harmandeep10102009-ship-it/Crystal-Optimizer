package com.deathmotion.marlowcrystal.util.datastructure;

import java.util.ArrayList;

/**
 * LRU-style evicting list for caching in 1.16.5
 * Removes oldest elements when max size is reached
 */
public class EvictingList<E> extends ArrayList<E> {
    private final int maxSize;

    public EvictingList(int maxSize) {
        super();
        this.maxSize = maxSize;
    }

    @Override
    public boolean add(E element) {
        if (this.size() >= this.maxSize) {
            this.remove(0);
        }
        return super.add(element);
    }

    @Override
    public void add(int index, E element) {
        if (this.size() >= this.maxSize) {
            this.remove(0);
        }
        super.add(index, element);
    }

    public int getMaxSize() {
        return this.maxSize;
    }

    @Override
    public void clear() {
        super.clear();
    }
}
