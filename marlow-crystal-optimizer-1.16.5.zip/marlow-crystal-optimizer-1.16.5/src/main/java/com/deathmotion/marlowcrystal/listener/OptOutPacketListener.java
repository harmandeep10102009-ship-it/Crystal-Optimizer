package com.deathmotion.marlowcrystal.listener;

import com.deathmotion.marlowcrystal.cache.OptOutCache;
import com.deathmotion.marlowcrystal.packet.impl.OptOutPacket;
import com.deathmotion.marlowcrystal.packet.impl.OptOutAckPacket;
import com.deathmotion.marlowcrystal.packet.ModPackets;
import com.deathmotion.marlowcrystal.util.Logger;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;

import java.util.UUID;

/**
 * Listener for opt-out packets from server
 * Manages player opt-out status for optimization
 */
public class OptOutPacketListener implements ClientPlayNetworking.PlayChannelHandler {

    @Override
    public void receive(MinecraftClient client, net.minecraft.network.NetworkHandler handler, PacketByteBuf buf, net.minecraft.network.PacketSender responseSender) {
        try {
            OptOutPacket optOut = OptOutPacket.decode(buf);
            
            if (client.player == null) {
                Logger.warn("Received opt-out packet but player is null");
                return;
            }
            
            UUID playerUUID = client.player.getUuid();
            
            if (optOut.isOptedOut()) {
                // Add player to opt-out cache
                OptOutCache.addOptOut(playerUUID);
                Logger.info("Player " + playerUUID + " opted out of Crystal Optimizer");
            } else {
                // Remove player from opt-out cache
                OptOutCache.removeOptOut(playerUUID);
                Logger.info("Player " + playerUUID + " opted in to Crystal Optimizer");
            }
            
            // Send acknowledgement
            OptOutAckPacket ack = new OptOutAckPacket(true);
            PacketByteBuf ackBuf = new PacketByteBuf(io.netty.buffer.Unpooled.buffer());
            ack.encode(ackBuf);
            
            responseSender.sendPacket(new net.minecraft.network.packet.c2s.common.CustomPayloadC2SPacket(ModPackets.OPT_OUT_ACK_PACKET, ackBuf));
            
            Logger.debug("Sent opt-out acknowledgement packet");
        } catch (Exception e) {
            Logger.error("Error processing opt-out packet: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
