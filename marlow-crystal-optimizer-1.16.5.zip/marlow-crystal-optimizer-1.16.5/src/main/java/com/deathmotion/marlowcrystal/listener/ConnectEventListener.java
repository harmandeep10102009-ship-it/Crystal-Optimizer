package com.deathmotion.marlowcrystal.listener;

import com.deathmotion.marlowcrystal.util.Logger;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;

/**
 * Listener for server connection events
 * Handles initialization when joining a server
 */
public class ConnectEventListener implements ClientPlayConnectionEvents.Join {

    @Override
    public void onPlayReady(ClientPlayConnectionEvents.Join.PlayReadyContext context) {
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null) {
                Logger.info("Connected to server - Crystal Optimizer active for player: " + client.player.getGameProfile().getName());
            } else {
                Logger.info("Connected to server - Crystal Optimizer active");
            }
        } catch (Exception e) {
            Logger.error("Error in connect listener: " + e.getMessage());
        }
    }
}
