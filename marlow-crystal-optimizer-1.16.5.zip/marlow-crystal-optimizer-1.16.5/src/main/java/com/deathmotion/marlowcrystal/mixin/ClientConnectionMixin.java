package com.deathmotion.marlowcrystal.mixin;

import com.deathmotion.marlowcrystal.util.Logger;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin for intercepting network packets
 * Allows monitoring of crystal-related packets
 */
@Mixin(ClientConnection.class)
public class ClientConnectionMixin {

    @Inject(method = "send", at = @At("HEAD"), cancellable = false)
    private void onSendPacket(Packet<?> packet, CallbackInfo ci) {
        try {
            // This mixin intercepts outgoing packets
            String packetName = packet.getClass().getSimpleName();
            
            // Only log crystal-related packets to reduce spam
            if (packetName.contains("Crystal") || packetName.contains("Entity")) {
                Logger.debug("Packet sent: " + packetName);
            }
        } catch (Exception e) {
            Logger.error("Error in send packet mixin: " + e.getMessage());
        }
    }

    @Inject(method = "handlePacket", at = @At("HEAD"), cancellable = false)
    private static void onHandlePacket(Packet<?> packet, net.minecraft.network.listener.PacketListener listener, CallbackInfo ci) {
        try {
            // This mixin intercepts incoming packets
            String packetName = packet.getClass().getSimpleName();
            
            // Only log crystal-related packets to reduce spam
            if (packetName.contains("Crystal") || packetName.contains("Entity") || packetName.contains("Explosion")) {
                Logger.debug("Packet received: " + packetName);
            }
        } catch (Exception e) {
            Logger.error("Error in handle packet mixin: " + e.getMessage());
        }
    }
}
