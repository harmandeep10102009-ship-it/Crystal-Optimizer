package com.deathmotion.marlowcrystal.util;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.util.Identifier;

/**
 * Connection utility for managing server connections in 1.16.5
 */
public class ConnectionUtil {

    public static boolean isConnectedToServer() {
        try {
            // In 1.16.5, we check if we can send packets
            return ClientPlayNetworking.canSend(new Identifier("test"));
        } catch (Exception e) {
            Logger.error("Error checking server connection: " + e.getMessage());
            return false;
        }
    }

    public static void sendPacketToServer(Identifier channel, net.minecraft.network.PacketByteBuf buf) {
        try {
            if (ClientPlayNetworking.canSend(channel)) {
                ClientPlayNetworking.send(channel, buf);
                Logger.debug("Packet sent to server: " + channel.toString());
            } else {
                Logger.warn("Cannot send packet - channel not available: " + channel.toString());
            }
        } catch (Exception e) {
            Logger.error("Error sending packet: " + e.getMessage());
        }
    }
}
