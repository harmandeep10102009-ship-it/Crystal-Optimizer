package com.deathmotion.marlowcrystal.packet.impl;

import net.minecraft.network.PacketByteBuf;

/**
 * Opt-out packet - allows players to opt out of optimization
 */
public class OptOutPacket {
    private boolean optedOut;

    public OptOutPacket(boolean optedOut) {
        this.optedOut = optedOut;
    }

    public OptOutPacket() {
        this(false);
    }

    public static OptOutPacket decode(PacketByteBuf buf) {
        boolean optedOut = buf.readBoolean();
        return new OptOutPacket(optedOut);
    }

    public void encode(PacketByteBuf buf) {
        buf.writeBoolean(this.optedOut);
    }

    public boolean isOptedOut() {
        return this.optedOut;
    }

    public void setOptedOut(boolean optedOut) {
        this.optedOut = optedOut;
    }
}
