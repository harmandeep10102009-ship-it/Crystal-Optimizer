package com.deathmotion.marlowcrystal.util;

import com.deathmotion.marlowcrystal.MarlowCrystal;

/**
 * Simple logger wrapper for 1.16.5
 * Uses SLF4J through Minecraft's logging
 */
public class Logger {
    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MarlowCrystal.MOD_NAME);

    public static void info(String message) {
        LOGGER.info("[" + MarlowCrystal.MOD_ID + "] " + message);
    }

    public static void warn(String message) {
        LOGGER.warn("[" + MarlowCrystal.MOD_ID + "] " + message);
    }

    public static void error(String message) {
        LOGGER.error("[" + MarlowCrystal.MOD_ID + "] " + message);
    }

    public static void debug(String message) {
        LOGGER.debug("[" + MarlowCrystal.MOD_ID + "] " + message);
    }
}
