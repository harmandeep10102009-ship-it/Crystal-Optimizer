package com.deathmotion.marlowcrystal.packet.impl;

import net.minecraft.network.PacketByteBuf;

/**
 * Version packet - used for version compatibility checking
 */
public class VersionPacket {
    private String clientVersion;
    private String serverVersion;

    public VersionPacket(String clientVersion, String serverVersion) {
        this.clientVersion = clientVersion;
        this.serverVersion = serverVersion;
    }

    public VersionPacket() {
        this("1.16.5", "1.16.5");
    }

    public static VersionPacket decode(PacketByteBuf buf) {
        String clientVersion = buf.readString(32767);
        String serverVersion = buf.readString(32767);
        return new VersionPacket(clientVersion, serverVersion);
    }

    public void encode(PacketByteBuf buf) {
        buf.writeString(this.clientVersion);
        buf.writeString(this.serverVersion);
    }

    public String getClientVersion() {
        return this.clientVersion;
    }

    public String getServerVersion() {
        return this.serverVersion;
    }

    public void setClientVersion(String clientVersion) {
        this.clientVersion = clientVersion;
    }

    public void setServerVersion(String serverVersion) {
        this.serverVersion = serverVersion;
    }
}
