package com.deathmotion.marlowcrystal.listener;

import com.deathmotion.marlowcrystal.cache.OptOutCache;
import com.deathmotion.marlowcrystal.util.Logger;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

/**
 * Listener for server disconnection events
 * Cleans up when leaving a server
 */
public class DisconnectEventListener implements ClientPlayConnectionEvents.Disconnect {

    @Override
    public void onPlayDisconnect(ClientPlayConnectionEvents.Disconnect.PlayDisconnectContext context) {
        try {
            Logger.info("Disconnected from server - cleaning up Crystal Optimizer");
            
            // Clear opt-out cache on disconnect
            OptOutCache.clear();
            
            Logger.debug("Crystal Optimizer cleanup complete");
        } catch (Exception e) {
            Logger.error("Error in disconnect listener: " + e.getMessage());
        }
    }
}
