package com.deathmotion.marlowcrystal.packet.impl;

import net.minecraft.network.PacketByteBuf;

/**
 * Opt-out acknowledgement packet - confirms opt-out status change
 */
public class OptOutAckPacket {
    private boolean acknowledged;

    public OptOutAckPacket(boolean acknowledged) {
        this.acknowledged = acknowledged;
    }

    public OptOutAckPacket() {
        this(true);
    }

    public static OptOutAckPacket decode(PacketByteBuf buf) {
        boolean acknowledged = buf.readBoolean();
        return new OptOutAckPacket(acknowledged);
    }

    public void encode(PacketByteBuf buf) {
        buf.writeBoolean(this.acknowledged);
    }

    public boolean isAcknowledged() {
        return this.acknowledged;
    }

    public void setAcknowledged(boolean acknowledged) {
        this.acknowledged = acknowledged;
    }
}
