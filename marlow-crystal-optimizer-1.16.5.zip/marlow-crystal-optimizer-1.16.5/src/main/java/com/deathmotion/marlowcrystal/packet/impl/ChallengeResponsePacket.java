package com.deathmotion.marlowcrystal.packet.impl;

import net.minecraft.network.PacketByteBuf;
import java.util.UUID;

/**
 * Challenge response packet - sent by client in response to challenge
 */
public class ChallengeResponsePacket {
    private UUID clientToken;
    private UUID serverToken;

    public ChallengeResponsePacket(UUID clientToken, UUID serverToken) {
        this.clientToken = clientToken;
        this.serverToken = serverToken;
    }

    public ChallengeResponsePacket() {
        this(UUID.randomUUID(), UUID.randomUUID());
    }

    public static ChallengeResponsePacket decode(PacketByteBuf buf) {
        UUID clientToken = buf.readUuid();
        UUID serverToken = buf.readUuid();
        return new ChallengeResponsePacket(clientToken, serverToken);
    }

    public void encode(PacketByteBuf buf) {
        buf.writeUuid(this.clientToken);
        buf.writeUuid(this.serverToken);
    }

    public UUID getClientToken() {
        return this.clientToken;
    }

    public UUID getServerToken() {
        return this.serverToken;
    }

    public void setClientToken(UUID clientToken) {
        this.clientToken = clientToken;
    }

    public void setServerToken(UUID serverToken) {
        this.serverToken = serverToken;
    }
}
