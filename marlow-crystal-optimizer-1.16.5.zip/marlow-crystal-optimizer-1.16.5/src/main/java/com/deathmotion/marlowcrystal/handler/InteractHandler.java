package com.deathmotion.marlowcrystal.handler;

import com.deathmotion.marlowcrystal.cache.OptOutCache;
import com.deathmotion.marlowcrystal.util.Logger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.world.World;

/**
 * Handler for End Crystal interactions and cleanup
 * Main optimization logic for 1.16.5
 */
public class InteractHandler {

    private static long lastCleanup = 0;
    private static final long CLEANUP_INTERVAL = 100; // ms

    /**
     * Tick handler - called every client tick
     * Manages End Crystal entity cleanup and optimization
     */
    public static void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            return;
        }

        // Throttle cleanup operations
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastCleanup < CLEANUP_INTERVAL) {
            return;
        }
        lastCleanup = currentTime;

        World world = client.world;
        
        // Scan for and manage end crystal entities
        for (Entity entity : world.getEntities()) {
            if (entity instanceof EndCrystalEntity) {
                EndCrystalEntity crystal = (EndCrystalEntity) entity;
                
                // Check if crystal has been hit/broken
                if (crystal.isDead()) {
                    Logger.debug("Cleaning up broken crystal entity: " + crystal.getEntityId());
                    // Entity will be automatically removed in next tick
                }
            }
        }
    }

    /**
     * Called when a crystal is broken
     */
    public static void onCrystalBreak(EndCrystalEntity crystal) {
        Logger.debug("Crystal break event detected at: " + crystal.getBlockPos());
    }

    /**
     * Called when a crystal is placed
     */
    public static void onCrystalPlaced(EndCrystalEntity crystal) {
        Logger.debug("Crystal placed at: " + crystal.getBlockPos());
    }

    /**
     * Clear all cached crystal data
     */
    public static void clearCache() {
        OptOutCache.clear();
        Logger.debug("Crystal cache cleared");
    }
}
