package com.deathmotion.marlowcrystal.packet.impl;

import net.minecraft.network.PacketByteBuf;
import java.util.UUID;

/**
 * Challenge packet - sent by server to verify client mod presence
 */
public class ChallengePacket {
    private UUID serverToken;

    public ChallengePacket(UUID serverToken) {
        this.serverToken = serverToken;
    }

    public ChallengePacket() {
        this(UUID.randomUUID());
    }

    public static ChallengePacket decode(PacketByteBuf buf) {
        UUID token = buf.readUuid();
        return new ChallengePacket(token);
    }

    public void encode(PacketByteBuf buf) {
        buf.writeUuid(this.serverToken);
    }

    public UUID getServerToken() {
        return this.serverToken;
    }

    public void setServerToken(UUID serverToken) {
        this.serverToken = serverToken;
    }
}
