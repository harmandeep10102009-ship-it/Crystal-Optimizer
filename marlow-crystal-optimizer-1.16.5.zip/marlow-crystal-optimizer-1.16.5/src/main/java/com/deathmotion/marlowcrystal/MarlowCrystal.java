package com.deathmotion.marlowcrystal;

import com.deathmotion.marlowcrystal.handler.InteractHandler;
import com.deathmotion.marlowcrystal.listener.ConnectEventListener;
import com.deathmotion.marlowcrystal.listener.DisconnectEventListener;
import com.deathmotion.marlowcrystal.packet.ModPackets;
import com.deathmotion.marlowcrystal.util.Logger;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

/**
 * Marlow's Crystal Optimizer - 1.16.5 Backport
 * Optimization for End Crystal entities cleanup
 */
public class MarlowCrystal implements ClientModInitializer {

    public static final String MOD_ID = "marlowcrystal";
    public static final String MOD_NAME = "Marlow's Crystal Optimizer";
    public static final String MOD_VERSION = "1.1.0-1.16.5";

    @Override
    public void onInitializeClient() {
        Logger.info("Initializing " + MOD_NAME + " v" + MOD_VERSION);

        try {
            // Register packet handlers
            ModPackets.registerPackets();

            // Register connection listeners
            ClientPlayConnectionEvents.JOIN.register(new ConnectEventListener());
            ClientPlayConnectionEvents.DISCONNECT.register(new DisconnectEventListener());

            // Register client tick event for interaction handling
            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                if (client != null) {
                    InteractHandler.tick(client);
                }
            });

            Logger.info("Crystal Optimizer initialized successfully");
        } catch (Exception e) {
            Logger.error("Failed to initialize Crystal Optimizer: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
