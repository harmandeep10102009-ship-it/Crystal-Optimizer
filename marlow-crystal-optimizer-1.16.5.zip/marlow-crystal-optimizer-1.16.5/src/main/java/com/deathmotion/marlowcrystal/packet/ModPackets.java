package com.deathmotion.marlowcrystal.packet;

import com.deathmotion.marlowcrystal.listener.ChallengePacketListener;
import com.deathmotion.marlowcrystal.listener.OptOutPacketListener;
import com.deathmotion.marlowcrystal.MarlowCrystal;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.util.Identifier;

/**
 * Packet registration for Crystal Optimizer
 * Handles all custom packet channels for 1.16.5
 */
public class ModPackets {
    public static final Identifier CHALLENGE_PACKET = new Identifier(MarlowCrystal.MOD_ID, "challenge");
    public static final Identifier CHALLENGE_RESPONSE_PACKET = new Identifier(MarlowCrystal.MOD_ID, "challenge_response");
    public static final Identifier OPT_OUT_PACKET = new Identifier(MarlowCrystal.MOD_ID, "opt_out");
    public static final Identifier OPT_OUT_ACK_PACKET = new Identifier(MarlowCrystal.MOD_ID, "opt_out_ack");
    public static final Identifier VERSION_PACKET = new Identifier(MarlowCrystal.MOD_ID, "version");

    public static void registerPackets() {
        try {
            // Register client packet receivers
            ClientPlayNetworking.registerGlobalReceiver(CHALLENGE_PACKET, new ChallengePacketListener());
            ClientPlayNetworking.registerGlobalReceiver(OPT_OUT_PACKET, new OptOutPacketListener());
        } catch (Exception e) {
            com.deathmotion.marlowcrystal.util.Logger.error("Failed to register packets: " + e.getMessage());
        }
    }
}
