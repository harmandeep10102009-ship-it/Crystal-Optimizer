package com.deathmotion.marlowcrystal.cache;

import com.deathmotion.marlowcrystal.util.datastructure.EvictingList;
import java.util.UUID;

/**
 * Cache for tracking players who have opted out of optimization
 */
public class OptOutCache {
    private static final EvictingList<UUID> optOutPlayers = new EvictingList<>(100);

    public static void addOptOut(UUID playerUUID) {
        if (!optOutPlayers.contains(playerUUID)) {
            optOutPlayers.add(playerUUID);
        }
    }

    public static void removeOptOut(UUID playerUUID) {
        optOutPlayers.remove(playerUUID);
    }

    public static boolean isOptedOut(UUID playerUUID) {
        return optOutPlayers.contains(playerUUID);
    }

    public static void clear() {
        optOutPlayers.clear();
    }

    public static int getSize() {
        return optOutPlayers.size();
    }
}
