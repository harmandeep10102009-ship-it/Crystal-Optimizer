package com.deathmotion.marlowcrystal.listener;

import com.deathmotion.marlowcrystal.packet.impl.ChallengePacket;
import com.deathmotion.marlowcrystal.packet.impl.ChallengeResponsePacket;
import com.deathmotion.marlowcrystal.packet.ModPackets;
import com.deathmotion.marlowcrystal.util.Logger;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;

import java.util.UUID;

/**
 * Listener for challenge packets from server
 * Responds to server challenges to verify mod presence
 */
public class ChallengePacketListener implements ClientPlayNetworking.PlayChannelHandler {

    @Override
    public void receive(MinecraftClient client, net.minecraft.network.NetworkHandler handler, PacketByteBuf buf, net.minecraft.network.PacketSender responseSender) {
        try {
            ChallengePacket challenge = ChallengePacket.decode(buf);
            
            Logger.debug("Received challenge packet from server with token: " + challenge.getServerToken());
            
            // Generate client token
            UUID clientToken = UUID.randomUUID();
            UUID serverToken = challenge.getServerToken();
            
            // Create and send response
            ChallengeResponsePacket response = new ChallengeResponsePacket(clientToken, serverToken);
            PacketByteBuf responseBuf = new PacketByteBuf(io.netty.buffer.Unpooled.buffer());
            response.encode(responseBuf);
            
            // Send the response back
            responseSender.sendPacket(new net.minecraft.network.packet.c2s.common.CustomPayloadC2SPacket(ModPackets.CHALLENGE_RESPONSE_PACKET, responseBuf));
            
            Logger.debug("Sent challenge response packet with client token: " + clientToken);
        } catch (Exception e) {
            Logger.error("Error processing challenge packet: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
