# Quick Start: Building Marlow's Crystal Optimizer 1.16.5

## For GitHub Codespaces (Mobile Friendly!)

### Step 1: Set Up Java 8
```bash
# Install SDKMAN (if not already installed)
curl -s "https://get.sdkman.io" | bash

# Load SDKMAN
source "$HOME/.sdkman/bin/sdkman-init.sh"

# Install Java 8
sdk install java 8.0.372-zulu

# Use Java 8
sdk use java 8.0.372-zulu

# Verify
java -version
# Should show: openjdk version "1.8.0_372"
```

### Step 2: Build the Mod
```bash
# Navigate to project
cd marlow-crystal-optimizer-1.16.5

# Build
./gradlew build

# Monitor build progress
# This takes 2-5 minutes on first build
```

### Step 3: Find Your JAR
```bash
# After successful build:
ls -lh build/libs/

# Output should show:
# marlow-crystal-optimizer-1.1.0-1.16.5.jar
```

### Step 4: Download & Install
```bash
# In Codespaces, download from:
# build/libs/marlow-crystal-optimizer-1.1.0-1.16.5.jar

# Place in your Minecraft mods folder:
# ~/.minecraft/mods/marlow-crystal-optimizer-1.1.0-1.16.5.jar
```

---

## For Local PC (Windows/Mac/Linux)

### Windows
```batch
# 1. Install Java 8 from oracle.com or adoptium.net
# 2. Verify installation
java -version

# 3. Build
gradlew.bat build

# 4. Find JAR in: build\libs\
```

### macOS/Linux
```bash
# 1. Install Java 8
# Ubuntu: sudo apt-get install openjdk-8-jdk
# macOS: brew install openjdk@8

# 2. Set JAVA_HOME
export JAVA_HOME=$(/usr/libexec/java_home -v 1.8)

# 3. Verify
java -version

# 4. Build
./gradlew build

# 5. Find JAR in: build/libs/
```

---

## Troubleshooting

### Issue: Java version error
```
Error: java version [21.0.10] does not match

Solution: 
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
./gradlew build
```

### Issue: No gradlew found
```
Error: No such file or directory: ./gradlew

Solution: You're in wrong directory. 
cd marlow-crystal-optimizer-1.16.5
```

### Issue: Build hangs
```
Solution: Press Ctrl+C and run:
./gradlew --stop
./gradlew build
```

---

## Next Steps

1. ✅ Build complete!
2. 📥 Download JAR from `build/libs/`
3. 📁 Place in `.minecraft/mods/`
4. 🎮 Launch Minecraft with Fabric
5. 🔍 Check logs - should see: `[marlowcrystal] Crystal Optimizer initialized successfully`

---

## Need Help?

- 📖 Read `BACKPORT_GUIDE.md` for detailed info
- 📝 Check `README.md` for features and config
- 🐛 Report issues on GitHub Issues
- 💬 Ask in GitHub Discussions

---

**Build Version**: 1.1.0-1.16.5  
**Last Updated**: June 15, 2026
